package com.demo;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

public class FruitMain {

	public static void main(String[] args) {

		List<Fruits> list=new ArrayList<>();
	    
	    list.add(new Fruits("litchi",50,"Red",100));
	    list.add(new Fruits("PineApple",50,"Yellow",100));
	    list.add(new Fruits("Banana",105,"Yellow",60));
	    list.add(new Fruits("watermelon",150,"green",85));
	    list.add(new Fruits("Grapes",50,"Black",65));
	    list.add(new Fruits("guava",90,"green",100));
	    
	    System.out.println("--------");
	   
	    List<String> list2=list.stream()
	    		.filter(p->p.getCalories()<100)
	    		.sorted(Comparator.comparing(Fruits::getCalories).reversed())
	    		.map(Fruits::getName)
	    		.collect(Collectors.toList());
	    list2.forEach(System.out::println);
	    
	    System.out.println("----------");
	    List<String> list3=list.stream()
	    		//.filter(p->p.getColor())
	    		.sorted(Comparator.comparing(Fruits::getColor))
	    		.map(Fruits::getName)
	    		.collect(Collectors.toList());
	    list3.forEach(System.out::println);
	    		
	    
	    System.out.println("--------");
	    
	    List<String> list4=list.stream()
	    		.filter(p->p.getColor()=="Red")
	    		.sorted(Comparator.comparing(Fruits::getPrice))
	    		.map(Fruits::getName)
	    		.collect(Collectors.toList());
	    list4.forEach(System.out::println);
	    		
	 
	   
	    
		
	
	}

}

	


