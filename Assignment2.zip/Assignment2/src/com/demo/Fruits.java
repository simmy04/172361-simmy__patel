package com.demo;

public class Fruits {
	private String name;
	private int calories;
	private String color;
	private int price;

		public Fruits(String name, int calories, String color, int price) {
			super();
			this.name = name;
			this.calories = calories;
			this.color = color;
			this.price = price;
		}
	
	 public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getCalories() {
		return calories;
	}
	public void setCalories(int calories) {
		this.calories = calories;
	}
	public String getColor() {
		return color;
	}
	public void setColor(String color) {
		this.color = color;
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	
	

}
