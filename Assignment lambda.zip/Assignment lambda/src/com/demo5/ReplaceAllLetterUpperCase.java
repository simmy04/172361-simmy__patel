package com.demo5;

import java.util.ArrayList;
import java.util.List;

public class ReplaceAllLetterUpperCase {

	public static void main(String[] args) {
		List<String> array = new ArrayList<String>();
		array.add("sim");
		array.add("simmypa");
		array.add("simsimmypa");
		array.add("rimmyp");
		System.out.println("Names :\n"+array);
		System.out.println("**********************************");
		
		array.replaceAll(sai -> sai.toUpperCase());
		array.forEach(System.out::println);
	}

}

	


