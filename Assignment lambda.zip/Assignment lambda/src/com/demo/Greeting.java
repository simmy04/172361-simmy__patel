package com.demo;
@FunctionalInterface
public interface Greeting {

	public double apply(double  value1,double value2);

}
