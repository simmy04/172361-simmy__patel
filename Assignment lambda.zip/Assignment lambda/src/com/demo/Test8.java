package com.demo;

public class Test8 {

	public static void main(String[] args) {
		Greeting add=(a,b)->a+b;
		Greeting subtract=(a,b)->a-b;
		Greeting divide=(a,b)->a/b;
		Greeting multiply=(a,b)->a*b;
		
		 double result1=add.apply( 12f,34f);
		 System.out.println(result1);
		 double result2=subtract.apply( 12,34f);
		 System.out.println(result2);
		 double result3=divide.apply( 12f,34f);
		 System.out.println(result3);
		 double result4=multiply.apply( 12f,34f);
		 System.out.println(result4);
		 

	}

}
