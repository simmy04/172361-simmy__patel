package com.demo4;

import java.util.ArrayList;
import java.util.List;

public class FirstLetterOfEachWordString {

	public static void main(String[] args) {
		List<String> array = new ArrayList<String>();
		array.add("Sim");
		array.add("simmypa");
		array.add("simsimmypa");
		array.add("rimmyp");
		System.out.println("Names :\n"+array);
		System.out.println("**********************************");
	
		String result = array.stream().map(sai -> Character.toString(sai.charAt(0))).reduce(" ", (a, b) -> a + b);
		System.out.println(result);
	
	}
}

	


