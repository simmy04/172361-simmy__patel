package com.demo1;
@FunctionalInterface
public interface OrderInterface {
	public void orders(double amt) ;


}	
