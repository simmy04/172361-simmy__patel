package com.demo1;

public class OrderTest {

	public static void main(String[] args) {
		OrderInterface o=(amt) -> {
			if(amt>10000)
				System.out.println("accepted");
			else
				System.out.println("completed");
		
			
		};
		o.orders(1500);
	}

}
